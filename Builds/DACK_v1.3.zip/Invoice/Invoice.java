package Invoice;

import customer.Customer;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime; // Import the LocalDateTime class
import java.time.format.DateTimeFormatter; // Import the DateTimeFormatter class
import java.util.ArrayList;
import java.util.Comparator;
import java.util.function.Function;

public class Invoice {

    private Customer customerInvoice;
    private LocalDateTime invoiceDate; // updates an invoice date and time
    private double initialInvoiceAmount; // total amount that's due initially
    private double remainingBalanace; // remaining portion to be paid
    private boolean invoiceStatus; // status determined for open/closed invoice
    private double deliveryCharge; // delivery percentage
    private double deliveryAmt;
    private final double discount = 0.10; // 10% deduction if invoice paid within 10 days
    private final double financeCharge = 0.02; // 2% charge if invoice paid after 30 days
    private int payDays = 0; // number of days it takes to pay the invoice
    public static Comparator<Invoice> byInvoiceDate;
    public static Comparator<Invoice> byInvoiceAmount;

    public Invoice(Customer customer, double invoiceTotal, boolean productDelivered) {
        if(productDelivered){
            deliveryCharge = 0.08;
            this.initialInvoiceAmount = invoiceTotal + (invoiceTotal * deliveryCharge); // apply a delivery charge to the total invoice amount
        } else {
            deliveryCharge = 0;
            this.initialInvoiceAmount = invoiceTotal;
        }
        this.deliveryAmt = invoiceTotal * deliveryCharge;
        this.customerInvoice = customer;
        this.invoiceDate = LocalDateTime.now();
        this.remainingBalanace = this.initialInvoiceAmount;
        this.invoiceStatus = true; // defualt value of invoice object is true (i.e. invoice is open)
    }

    public Customer getCustomerInvoice() {
        return this.customerInvoice;
    }

    public void setCustomerInvoice(Customer customer) {
        this.customerInvoice = customer;
    }

    public LocalDateTime getInvoiceDate() {
        return this.invoiceDate;
    }

    public void setInvoiceDate(LocalDateTime date){
        this.invoiceDate = date;
    }

    public double getInitialInvoiceAmount() {
        return this.initialInvoiceAmount;
    }

    public void setInitialInvoiceAmount(double invoiceAmount) {
        this.initialInvoiceAmount = invoiceAmount;
    }

    public double getRemainingBalanace() {
        return this.remainingBalanace;
    }

    public void setRemainingBalanace(double totalDue) {
        this.remainingBalanace = totalDue;
    }

    public double getDeliveryCharge() {
        return this.deliveryCharge;
    }

    public void setInvoiceStatus(boolean status){
        this.invoiceStatus = status;
    }

    public boolean getInvoiceStatus(){
        return this.invoiceStatus;
    }

    public void updateRemainingBalance(double updateAmount){
        this.remainingBalanace -= updateAmount;
        if (this.remainingBalanace <= 0) {
            setInvoiceStatus(false);
        }
    }

    public void applyDiscount() {
        if(this.payDays < 10){
            this.initialInvoiceAmount = this.initialInvoiceAmount - (this.initialInvoiceAmount * this.discount);
        }
    }

    public void applyFinanceCharge(){
        if(this.payDays > 30){
            this.initialInvoiceAmount = this.initialInvoiceAmount + (this.initialInvoiceAmount * this.financeCharge);
        }
    }

    public void incrementPayDay(int n) {
        payDays += n;
    }

    public void writeInvoice() {
        try {
            FileWriter writer = new FileWriter(customerInvoice.getName() + " Invoice.txt");
            String balanceStr = String.format("%.2f", remainingBalanace);
            String initialInvoiceAmt = String.format("%.2f", initialInvoiceAmount);
            DateTimeFormatter myFirstFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
            String firstFormattedDate = invoiceDate.format(myFirstFormatObj);
            String deliveryAmtStr = String.format("%.2f", deliveryAmt);
            writer.write("Customer Name: " + customerInvoice.getName() + "\n" +
                    "Invoice Date: " + firstFormattedDate + "\n" +
                    "Invoice Amount: $" + initialInvoiceAmt + "\n" +
                    "Delivery Charge: $" + deliveryAmtStr + "\n" +
                    customerInvoice.getItemsBought() +
                    "Total Due: $" + balanceStr + "\n");
            writer.flush();
            writer.close();
        }
        catch (IOException e){
            System.out.println("Error");
        }
    }

    public void displayInvoice() {
        try {
            writeInvoice();

            BufferedReader reader = new BufferedReader(new FileReader(customerInvoice.getName() + " Invoice.txt"));

            String line = reader.readLine();
            ArrayList<String> invoice = new ArrayList<String>();

            while (line != null) {
                invoice.add(line);
                line = reader.readLine();
            }
            reader.close();

            for (int i = 0; i < invoice.size(); i++){
                if (i == 0) {
                    System.out.print("|" + invoice.get(i));
                    continue;
                }
                else if (i == 1) {
                    System.out.printf("%81s|", invoice.get(i));
                }
                else if (i == invoice.size() - 1) {
                    System.out.printf("|%100s|", invoice.get(i));
                }
                else {
                    if (i == 4){
                        System.out.printf("|%-100s|%n", " ");
                        System.out.printf("|%-100s|%n", "Purchased Items: ");
                        System.out.printf("|%-100s|", invoice.get(i));
                    } else {
                        System.out.printf("|%-100s|", invoice.get(i));

                    }
                }
                System.out.println();
            }
        }
        catch(IOException e) {
            System.out.println("Error");
        }
    }

    static {
        Invoice.byInvoiceDate = Comparator.comparing((Function<? super Invoice, ? extends Comparable>)Invoice::getInvoiceDate);
        Invoice.byInvoiceAmount = Comparator.comparing((Function<? super Invoice, ? extends Comparable>)Invoice::getInitialInvoiceAmount);
    }

}