import java.io.IOException;

import Invoice.Invoice;

public class InvoiceTester{
    public static void main(String[] args) throws IOException{
//        Invoice i = new Invoice("Alex", "11/27/2019", 250, 250, 0);
//        i.displayInvoice();
    }
}