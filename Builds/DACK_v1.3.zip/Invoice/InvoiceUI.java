package Invoice;


import java.util.Scanner; // imported to read user input
import Invoice.InvoiceController;
public class InvoiceUI
{
    private InvoiceController invoiceControl;

    public InvoiceUI(InvoiceController customerInvoice){
        this.invoiceControl = customerInvoice;
    }

    // UI Boundary takes input from user may modify Invoice using Invoice Controller
    public void UIBoundary(final Scanner input){

        System.out.println("Enter customer name: ");
        final String customerName = input.nextLine();

        System.out.println("Enter customer number: ");
        final String customerNumber = input.nextLine();

        //verify customer exists
        if(this.invoiceControl.verifyCustomerExists(customerName, customerNumber)){
            System.out.println("Enter order info");
        } else {

        }
    }
}
