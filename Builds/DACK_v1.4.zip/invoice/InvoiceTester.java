import java.io.IOException;

public class InvoiceTester{
    public static void main(String[] args) throws IOException{
//        invoice i = new invoice("Alex", "11/27/2019", 250, 250, 0);
//        i.displayInvoice();
    }
}