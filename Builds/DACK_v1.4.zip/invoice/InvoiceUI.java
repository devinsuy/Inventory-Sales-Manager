package invoice;


import java.util.Scanner; // imported to read user input

public class InvoiceUI
{
    private InvoiceController invoiceControl;

    public InvoiceUI(InvoiceController customerInvoice){
        this.invoiceControl = customerInvoice;
    }

    // UI Boundary takes input from user may modify invoice using invoice Controller
    public void UIBoundary(final Scanner input){

        System.out.println("Enter customer name: ");
        final String customerName = input.nextLine();

        System.out.println("Enter customer number: ");
        final String customerNumber = input.nextLine();

        //verify customer exists
        if(this.invoiceControl.verifyCustomerExists(customerName, customerNumber)){
            System.out.println("Enter order info");
        } else {

        }
    }
}
