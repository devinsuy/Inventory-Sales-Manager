package customer;

import mainmenu.MainMenu;

import java.util.Scanner;

public class CustomerTester {
    public static void main(String [] args){
        CustomerController c = new CustomerController(new MainMenu());
//        c.writeCustomer(new Customer("a", "a", "a", 0.0));
        System.out.println("Customers List: ");
        c.enterCustomer(new Scanner(System.in), false);
//        System.out.println(c.getCustomerArrayList().toString());

    }
}
