package Invoice;

import customer.Customer;
import java.time.LocalDateTime; // Import the LocalDateTime class

public class Invoice {

    private Customer customerInvoice;
    private LocalDateTime invoiceDate; // updates an invoice date and time
    private double initialInvoiceAmount; // total amount that's due initially
    private double remainingBalanace; // remaining portion to be paid
    private boolean invoiceStatus; // status determined for open/closed invoice
    private final double deliveryCharge = 0.08; // delivery percentage
    private final double discount = 0.10; // 10% deduction if invoice paid within 10 days
    private final double financeCharge = 0.02; // 2% charge if invoice paid after 30 days
    private int payDays = 0; // number of days it takes to pay the invoice

    public Invoice(Customer customer, LocalDateTime invoiceDate, double invoiceTotal, double amountPaid, boolean productDelivered) {
        if(productDelivered){
            this.initialInvoiceAmount = invoiceTotal + (invoiceTotal * deliveryCharge); // apply a delivery charge to the total invoice amount
        } else {
            this.initialInvoiceAmount = invoiceTotal;
        }
        this.customerInvoice = customer;
        this.invoiceDate = invoiceDate;
        this.remainingBalanace = amountPaid;
        this.invoiceStatus = true; // defualt value of invoice object is true (i.e. invoice is open)
    }

    public Customer getCustomerInvoice() {
        return this.customerInvoice;
    }

    public void setCustomerInvoice(Customer customer) {
        this.customerInvoice = customer;
    }

    public LocalDateTime getInvoiceDate() {
        return this.invoiceDate;
    }

    public void setInvoiceDate(LocalDateTime date){
        this.invoiceDate = date;
    }

    public double getInitialInvoiceAmount() {
        return this.initialInvoiceAmount;
    }

    public void setInitialInvoiceAmount(double invoiceAmount) {
        this.initialInvoiceAmount = invoiceAmount;
    }

    public double getRemainingBalanace() {
        return this.remainingBalanace;
    }

    public void setRemainingBalanace(double totalDue) {
        this.remainingBalanace = totalDue;
    }

    public double getDeliveryCharge() {
        return this.deliveryCharge;
    }

    public void setInvoiceStatus(boolean status){
        this.invoiceStatus = status;
    }

    public boolean getInvoiceStatus(){
        return this.invoiceStatus;
    }

    public void updateRemainingBalance(double updateAmount){
        this.remainingBalanace -= updateAmount;
    }

    public void applyDiscount() {
        if(this.payDays < 10){
            this.initialInvoiceAmount = this.initialInvoiceAmount - (this.initialInvoiceAmount * this.discount);
        }
    }

    public void applyFinanceCharge(){
        if(this.payDays > 30){
            this.initialInvoiceAmount = this.initialInvoiceAmount + (this.initialInvoiceAmount * this.financeCharge);
        }
    }

    public void incrementPayDay(int n){
        if(n > 0){
            while(n > 0){
                this.payDays++;
                n--;
            }
        }
    }
}