package Invoice;

import customer.Customer;
import java.util.ArrayList;

/* The invoice controller class modifies
 * the data for an invoice
 */
public class InvoiceController
{
    private Invoice invoice;
    private ArrayList<Customer> listOfCustomers = new ArrayList<Customer>();
    private ArrayList<Invoice> invoiceList = new ArrayList<Invoice>();

    public InvoiceController(Invoice customerInvoice, ArrayList<Customer> customers) {
        //before an invoice can be created, a customer must exist in database
        //check to see if customer exists in database
        this.listOfCustomers = customers;
        this.invoice = customerInvoice;
    }
    public boolean verifyCustomerExists(String name, String number){
        String customerName, customerNumber;
        for(int i = 0; i < this.listOfCustomers.size(); i++){
            customerName = this.listOfCustomers.get(i).getName();
            customerNumber = this.listOfCustomers.get(i).getNumber();
            if(name.equals(customerName) && number.equals(customerNumber)){
                return true;
            }
        }
        return false;
    }
    public void addInvoice(Invoice customerInvoice){
        this.invoiceList.add(customerInvoice);
    }
}
